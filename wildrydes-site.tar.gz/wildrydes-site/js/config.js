window._config = {
    cognito: {
        userPoolId: 'eu-west-1_PVZfsiKK3', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '4bt98fspapn2alsjgnvnoijidb', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'eu-west-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: ' https://22y2mly6l0.execute-api.eu-west-1.amazonaws.com/prod' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
